<?php
/**
 * Plugin Name:       Primekidz Companion
 * Plugin URI:        http://primekidz.cf/plugin
 * Description:       Primekidz Companio is a companion plugin for primekidz theme
 * Version:           1.0
 * Author:            The Advanced Technologies
 * Author URI:        http://theadvancedtechnologies.com
 * Text Domain:       primekidzcompanio
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

function cptui_register_my_cpts() {

	/**
	 * Post Type: Courses.
	 */

	$labels = array(
		"name" => __( "Courses", "" ),
		"singular_name" => __( "Course", "" ),
		"featured_image" => __( "Course Image", "" ),
		"set_featured_image" => __( "Set Course Image", "" ),
		"remove_featured_image" => __( "Remove Course Image", "" ),
		"use_featured_image" => __( "Use Course Image", "" ),
	);

	$args = array(
		"label" => __( "Courses", "" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "Course", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-welcome-learn-more",
		"supports" => array( "title", "editor", "thumbnail" ),
	);

	register_post_type( "Course", $args );

	/**
	 * Post Type: Gallerys.
	 */

	$labels = array(
		"name" => __( "Gallerys", "" ),
		"singular_name" => __( "Gallery", "" ),
		"featured_image" => __( "Gallery Image", "" ),
		"set_featured_image" => __( "Set Gallery Image", "" ),
		"remove_featured_image" => __( "Remove Gallery Image", "" ),
		"use_featured_image" => __( "Use Gallery Image", "" ),
	);

	$args = array(
		"label" => __( "Gallerys", "" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "gallery", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-format-gallery",
		"supports" => array( "title", "post-formats" ),
	);

	register_post_type( "gallery", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );

